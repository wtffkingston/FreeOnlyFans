import subprocess
import requests
import json
import webbrowser

# Config
leakcheckAPI = None # Enter here your API Key if you want to use leakcheck.io for searching :)

print("Open your default browser")
print("-----------------------------")
print("[+]FreeOnlyFans[+]")
print("-----------------------------")
print(" >[1]", "(Has Ads)")
print(" >[2]","(Best Option)")
print("-----------------------------")
print("-----------------------------")
# Modules












option = input("[+]Select option: ")
if (option == "1"):
    webbrowser.open('https://bitchesgirls.com/', new=2)
if (option == "2"):
    webbrowser.open('https://onlyfuckme.com/', new=2)    
    